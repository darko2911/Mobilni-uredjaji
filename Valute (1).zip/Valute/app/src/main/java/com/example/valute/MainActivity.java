package com.example.valute;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText etEuro;
    private Button btnConvert;
    private TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etEuro = findViewById(R.id.et_euro);
        btnConvert = findViewById(R.id.btn_convert);
        tvResult = findViewById(R.id.tv_result);

        btnConvert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double euro = Double.parseDouble(etEuro.getText().toString());
                double usd = euro * 1.12;
                double gbp = euro * 0.85;
                double jpy = euro * 129.53;
                double aud = euro * 1.61;

                String result = "USD: " + usd + "\n" +
                                "GBP: " + gbp + "\n" +
                                "JPY: " + jpy + "\n" +
                                "AUD: " + aud;

                tvResult.setText(result);
            }
        });
    }
}