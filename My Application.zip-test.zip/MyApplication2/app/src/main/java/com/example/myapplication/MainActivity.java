package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.myapplication.R;

public class MainActivity extends AppCompatActivity {

    private TextView textViewUpis;

    private EditText editTextInsert;

    private ImageView imageViewSlika;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textViewUpis = findViewById(R.id.textViewUpis);
        editTextInsert = findViewById(R.id.editTextInsert);
        imageViewSlika= findViewById(R.id.imageViewSlika);
    }

    public void clickButtonTexst(View view)
    {

        String text="";
        text= editTextInsert.getText().toString();

        textViewUpis.setText(text);

    }
    public void clickButtonSlika(View viev)
    {

        imageViewSlika.setImageResource(R.drawable.osijek);
    }
    public void clickButtonDrugaSlika(View viev)
    {

        imageViewSlika.setImageResource(R.drawable.hajduk);
    }

}