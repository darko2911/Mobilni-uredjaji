package easy.tuto.myquizapplication;

public class QuestionAnswer {

    public static String question[] ={
            "Odakle dolazi domagoj Vida?",
            "Odakle dolazi Luka Modrić?",
            "Odakle dolazi Joško Gvardiol?",
            "Odakle dolazi Ivan Perišić?"
    };

    public static String choices[][] = {
            {"Zagreb","Požega","Donji Miholjac","Osijek"},
            {"Modrića","Sikova","Zadra","Makarske"},
            {"Zagreb","Varaždin","Karlovac","Split"},
            {"Sinj","Split","Vrlika","Dubrovnik"}
    };

    public static String correctAnswers[] = {
            "Donji Miholjac",
            "Modrića",
            "Zagreb",
            "Split"
    };

}
